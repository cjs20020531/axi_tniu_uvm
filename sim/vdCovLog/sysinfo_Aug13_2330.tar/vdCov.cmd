gui_exclusion -set_force true
gui_assert_mode -mode flat
gui_class_mode -mode hier
gui_excl_mgr_flat_list -on  0
gui_covdetail_select -id  CovDetail.1   -name   Line
verdiWindowWorkMode -win $_vdCoverage_1 -coverageAnalysis
gui_open_cov  -hier cov.vdb -testdir {} -test {cov/test_norm_rdw_1 cov/test_norm_wrw_1 cov/test_watchdog_1023_1 cov/test_watchdog_1024_1 cov/test_watchdog_normal_timeout_1 cov/test_tag_name_toggle_1 cov/test_norm_rdw_narrow_noalign_1 cov/test_norm_wrw_narrow_noalign_1 cov/test_watchdog_1100_1 cov/test_norm_mix_stresstest_1 cov/test_err_rd_1 cov/test_err_wr_1 cov/test_err_rdw_1 cov/test_err_wrw_1 cov/test_err_mix_1 cov/test_err_mix_fixordkey_1 cov/test_buff_wr_1 cov/test_buff_wrw_1 cov/test_buff_mix_1 cov/test_buff_mix_fixordkey_1 cov/test_buff_err_mix_1 cov/test_addrol_waw_1 cov/test_addrol_raw_1 cov/test_axi_rsp_error_mix_1 cov/test_mix_1 cov/test_aresetn_recovery_1 cov/test_norm_rd_1 cov/test_norm_wr_1 cov/test_norm_mix_1 cov/test_watchdog_bufferable_1100_1} -merge MergedTest -db_max_tests 10 -fsm transition
gui_list_expand -id  CoverageTable.1   -list {covtblInstancesList} tb_top
gui_list_expand -id  CoverageTable.1   -list {covtblInstancesList} tb_top.dut
gui_list_expand -id  CoverageTable.1   -list {covtblInstancesList} tb_top.dut.U_REQ_ORDER
gui_list_select -id CoverageTable.1 -list covtblInstancesList { tb_top.dut.U_REQ_ORDER   }
gui_list_sort -id  CoverageTable.1   -list {covtblInstancesList} {Toggle}
gui_list_action -id  CoverageTable.1 -list {covtblInstancesList} tb_top.dut.U_REQ_ORDER  -column {Toggle} 
gui_list_select -id CovDetail.1 -list tglDetail { {rknp_xx2reqo_data[174:49]}   }
gui_list_select -id CovDetail.1 -list tgl { {rknp_xx2reqo_data[174:0]}  {opc[3:0]}   }
gui_list_select -id CovDetail.1 -list tglDetail { {opc[3]}   }
gui_exclude_items -id  CovDetail.1  -list { tglDetail }  -selected
gui_annotation_dlg -opt add
